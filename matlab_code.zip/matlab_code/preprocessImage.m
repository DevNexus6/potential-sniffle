function grayImg = preprocessImage(srcImg)
% PREPROCESSIMAGE 图像预处理：灰度化 + 中值滤波降噪
%   输入：
%       srcImg  - 原始RGB或灰度图像 (uint8)
%   输出：
%       grayImg - 预处理（灰度化+降噪）后的灰度图像 (double, [0,1])
%
%   说明：
%   1) 若输入为彩色图，先转换为灰度图；
%   2) 使用 3x3 中值滤波器去除椒盐噪声等孤立噪点，同时较好地保留数字笔画边缘；
%   3) 归一化到 [0,1] 便于后续统一处理。

    if size(srcImg, 3) == 3
        gray = rgb2gray(srcImg);
    else
        gray = srcImg;
    end

    gray = im2double(gray);

    % 中值滤波降噪（3x3窗口），对椒盐噪声效果显著且不会过度模糊边缘
    denoised = medfilt2(gray, [3 3]);

    grayImg = denoised;
end
