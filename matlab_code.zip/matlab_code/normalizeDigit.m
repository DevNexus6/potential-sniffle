function normImg = normalizeDigit(digitCrop, targetSize)
% NORMALIZEDIGIT 将裁剪出的数字区域等比例缩放并居中填充到统一尺寸
%   输入：
%       digitCrop  - 分割裁剪出的数字二值图 (logical)
%       targetSize - 归一化后的目标尺寸（正方形边长，如 32）
%   输出：
%       normImg    - targetSize x targetSize 的归一化二值图 (logical)
%
%   说明：
%   不同图片中数字的大小、长宽比各不相同，直接强行拉伸为正方形会
%   扭曲数字形状，影响模板匹配精度。因此这里保持原始长宽比，将数字
%   等比例缩放到 (targetSize*0.75) 大小的内接区域，再居中贴到
%   targetSize x targetSize 的黑色画布上，与模板图像的生成方式保持一致，
%   从而保证测试图像与模板在同一"坐标体系"下进行比较。

    [h, w] = size(digitCrop);
    innerSize = round(targetSize * 0.75);
    scale = innerSize / max(h, w);
    newH = max(1, round(h * scale));
    newW = max(1, round(w * scale));

    resized = imresize(double(digitCrop), [newH, newW], 'bilinear');
    resized = resized > 0.5;   % 重新二值化，避免插值产生灰度过渡

    canvas = false(targetSize, targetSize);
    offY = floor((targetSize - newH) / 2) + 1;
    offX = floor((targetSize - newW) / 2) + 1;
    canvas(offY:offY+newH-1, offX:offX+newW-1) = resized;

    normImg = canvas;
end
