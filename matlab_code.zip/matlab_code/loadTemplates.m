function templates = loadTemplates(templateDir, targetSize)
% LOADTEMPLATES 加载 0-9 标准数字模板图像
%   输入：
%       templateDir - 模板图片所在文件夹（文件命名为 template_0.png ... template_9.png）
%       targetSize  - 模板应有的尺寸（用于校验/统一尺寸）
%   输出：
%       templates   - 1x10 cell 数组，templates{i} 对应数字 (i-1) 的模板
%                     （logical 矩阵，数字笔画为1，背景为0）
%
%   说明：
%   模板为预先制作的标准印刷体数字二值图像（居中、归一化到 targetSize），
%   与 normalizeDigit.m 采用完全相同的归一化规则生成，保证测试图像与
%   模板在比较时处于同一尺度和坐标体系下，以提升模板匹配的准确性。

    templates = cell(1, 10);
    for d = 0:9
        fname = fullfile(templateDir, sprintf('template_%d.png', d));
        if ~exist(fname, 'file')
            error('模板文件缺失: %s', fname);
        end
        img = imread(fname);
        if size(img, 3) == 3
            img = rgb2gray(img);
        end
        bwTpl = img > 127;   % 模板已经是黑白图，白色(255)为数字笔画

        % 若尺寸与目标不一致，做一次缩放兜底
        if ~isequal(size(bwTpl), [targetSize, targetSize])
            bwTpl = imresize(double(bwTpl), [targetSize, targetSize], 'bilinear') > 0.5;
        end

        templates{d + 1} = bwTpl;
    end
end
