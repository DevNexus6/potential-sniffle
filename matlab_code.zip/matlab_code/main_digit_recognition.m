%% main_digit_recognition.m
% =========================================================================
% 《机器视觉与图像处理》大作业 —— 方向3：单数字图像识别系统（简易OCR）
% 功能：对输入图片中的单个印刷/手写数字(0-9)进行预处理、降噪、二值化分割、
%       轮廓特征提取，并通过模板匹配算法输出识别结果。
%
% 使用方法：
%   1. 直接运行本脚本，将对 test_images 文件夹下第一张测试图片进行识别演示；
%   2. 或修改 imgPath 变量指向你自己的数字图片；
%   3. 运行 batch_test.m 可对 test_images 文件夹内全部样本做批量测试并统计正确率。
%
% 作者：（请在此填写姓名/学号）
% =========================================================================

clear; clc; close all;

%% ---------- 1. 参数与路径设置 ----------
imgPath   = fullfile('test_images', 'test_00_digit0.jpg');   % 待识别图片路径
templateDir = 'templates';                                    % 标准模板所在目录
targetSize  = 32;                                              % 归一化尺寸 32x32

%% ---------- 2. 读取图像 ----------
if ~exist(imgPath, 'file')
    error('找不到图片: %s，请检查路径设置。', imgPath);
end
srcImg = imread(imgPath);

%% ---------- 3. 图像预处理（灰度化 + 中值滤波降噪）----------
grayImg = preprocessImage(srcImg);

%% ---------- 4. 二值化分割（Otsu自适应阈值）----------
[bwImg, thresh] = binarizeImage(grayImg);

%% ---------- 5. 轮廓特征提取（连通域分析，定位数字外接矩形并裁剪）----------
[digitCrop, bbox] = segmentDigit(bwImg);
if isempty(digitCrop)
    error('未检测到有效的数字区域，请更换图片或检查二值化效果。');
end

%% ---------- 6. 尺寸归一化 ----------
normImg = normalizeDigit(digitCrop, targetSize);

%% ---------- 7. 加载模板并进行模板匹配 ----------
templates = loadTemplates(templateDir, targetSize);
[predLabel, scores] = templateMatch(normImg, templates);

%% ---------- 8. 结果输出与可视化 ----------
fprintf('=========================================\n');
fprintf('  识别结果：数字 %d  （匹配相关系数 = %.4f）\n', predLabel, scores(predLabel+1));
fprintf('=========================================\n');
fprintf('各数字模板匹配得分：\n');
for d = 0:9
    fprintf('   数字 %d : %.4f\n', d, scores(d+1));
end

figure('Name', '单数字识别流程', 'Position', [100 100 1400 320]);

subplot(1,5,1); imshow(srcImg);      title('原图 (Original)');
subplot(1,5,2); imshow(grayImg);     title('灰度图 (Grayscale)');
subplot(1,5,3); imshow(bwImg);       title(sprintf('Otsu二值化\n阈值=%.2f', thresh));

% 在原灰度图上画出检测到的数字外接矩形，展示"轮廓特征提取"效果
% bbox = [minRow, minCol, maxRow, maxCol]
subplot(1,5,4); imshow(grayImg); title('数字定位/分割'); hold on;
rectangle('Position', [bbox(2), bbox(1), bbox(4)-bbox(2), bbox(3)-bbox(1)], ...
    'EdgeColor', 'r', 'LineWidth', 2);
hold off;

subplot(1,5,5); imshow(normImg);
title(sprintf('归一化+识别结果\n预测数字: %d', predLabel));

sgtitle('单数字识别系统处理流程');
