function [bwImg, thresh] = binarizeImage(grayImg)
% BINARIZEIMAGE 使用 Otsu 自适应阈值法对图像进行二值化分割
%   输入：
%       grayImg - 预处理后的灰度图 (double, [0,1])
%   输出：
%       bwImg   - 二值图像 (logical)，数字笔画区域为 1（白），背景为 0（黑）
%       thresh  - 计算得到的Otsu阈值 (归一化到[0,1])
%
%   说明：
%   1) graythresh 使用 Otsu 方法自动计算全局最优阈值，能够较好地适应
%      不同拍摄条件下（光照、对比度差异）的图像二值化需求；
%   2) 数字笔画通常比背景颜色深（灰度值更低）。先以"灰度值低于阈值"
%      作为候选前景，再统计其像素占比：若候选前景占比超过图像面积的
%      一半，说明实际情况是"背景暗、数字亮"，此时对结果取反，
%      从而保证无论原图明暗关系如何，数字笔画在 bwImg 中始终为 1（白）、
%      背景始终为 0（黑），便于后续统一做连通域分析。

    thresh = graythresh(grayImg);          % Otsu自动阈值（[0,1]）

    candidateFg = grayImg < thresh;        % 灰度值低于阈值 -> 候选前景(数字)
    fgRatio = sum(candidateFg(:)) / numel(candidateFg);

    if fgRatio > 0.5
        % 候选前景占比过大，说明实际是背景暗、数字亮，取反使数字为1
        bwImg = ~candidateFg;
    else
        bwImg = candidateFg;
    end
end
