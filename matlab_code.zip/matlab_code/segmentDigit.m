function [digitCrop, bbox] = segmentDigit(bwImg)
% SEGMENTDIGIT 基于连通域分析的数字定位与分割（轮廓特征提取）
%   输入：
%       bwImg     - 二值图像 (logical)，数字为1，背景为0
%   输出：
%       digitCrop - 裁剪出的数字区域二值图 (logical)；若未检测到目标则为 []
%       bbox      - 数字外接矩形 [minRow, minCol, maxRow, maxCol]
%
%   说明：
%   使用 bwlabel 进行连通域标记，regionprops 提取每个连通域的面积
%   (Area) 与外接矩形 (BoundingBox) 等轮廓特征；选取面积最大的连通域
%   作为目标数字（可有效排除图像中细小噪点或背景杂质干扰），
%   并按其外接矩形从二值图中裁剪出数字区域。

    cc = bwlabel(bwImg);
    stats = regionprops(cc, 'Area', 'BoundingBox');

    if isempty(stats)
        digitCrop = [];
        bbox = [];
        return;
    end

    % 选择面积最大的连通域作为数字主体，排除噪点干扰
    areas = [stats.Area];
    [~, idx] = max(areas);
    bboxRaw = stats(idx).BoundingBox;   % [x, y, width, height] (x=col, y=row)

    minCol = round(bboxRaw(1));
    minRow = round(bboxRaw(2));
    w      = round(bboxRaw(3));
    h      = round(bboxRaw(4));
    maxCol = minCol + w - 1;
    maxRow = minRow + h - 1;

    % 边界保护
    minCol = max(minCol, 1); minRow = max(minRow, 1);
    maxCol = min(maxCol, size(bwImg,2)); maxRow = min(maxRow, size(bwImg,1));

    digitCrop = bwImg(minRow:maxRow, minCol:maxCol);
    bbox = [minRow, minCol, maxRow, maxCol];
end
