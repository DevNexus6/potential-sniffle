function [predLabel, scores] = templateMatch(normImg, templates)
% TEMPLATEMATCH 模板匹配：计算待识别数字与0-9模板的相似度并输出最优匹配
%   输入：
%       normImg   - 归一化后的待识别数字二值图 (targetSize x targetSize, logical)
%       templates - loadTemplates 得到的 1x10 模板 cell 数组
%   输出：
%       predLabel - 识别结果（0-9）
%       scores    - 1x10 向量，scores(i) 为与数字 (i-1) 模板的相关系数
%
%   算法原理：
%   采用归一化相关系数（Normalized Cross-Correlation, NCC）衡量两幅
%   二值图像的相似程度：
%       NCC = sum((A-mean(A)).*(B-mean(B))) / (norm(A-mean(A)) * norm(B-mean(B)))
%   NCC 取值范围为 [-1, 1]，值越大表示待识别图像与该模板越相似。
%   相比直接计算像素差异（如汉明距离），NCC 对图像整体亮度/对比度的
%   微小差异不敏感，鲁棒性更好，是模板匹配中的常用相似性度量。
%   最终选取10个模板中相关系数最高者对应的数字作为识别结果。

    A = double(normImg(:));
    Am = A - mean(A);
    An = norm(Am) + eps;   % 加 eps 防止除零

    scores = zeros(1, 10);
    for i = 1:10
        B = double(templates{i}(:));
        Bm = B - mean(B);
        Bn = norm(Bm) + eps;
        scores(i) = (Am' * Bm) / (An * Bn);
    end

    [~, maxIdx] = max(scores);
    predLabel = maxIdx - 1;   % cell索引从1开始，数字从0开始，需要-1
end
