%% batch_test.m
% =========================================================================
% 批量测试脚本：对 test_images 文件夹下全部测试图片进行识别，
% 并根据 labels.csv 中的真实标签统计识别正确率与混淆矩阵。
% =========================================================================

clear; clc; close all;

testDir     = 'test_images';
templateDir = 'templates';
targetSize  = 32;

%% 读取标签文件
labelFile = fullfile(testDir, 'labels.csv');
labelTable = readtable(labelFile, 'TextType', 'string');

numSamples = height(labelTable);
predLabels = zeros(numSamples, 1);
trueLabels = labelTable.true_label;

templates = loadTemplates(templateDir, targetSize);

%% 逐张识别
for k = 1:numSamples
    fname = labelTable.filename(k);
    imgPath = fullfile(testDir, fname);
    srcImg = imread(imgPath);

    grayImg = preprocessImage(srcImg);
    [bwImg, ~] = binarizeImage(grayImg);
    [digitCrop, ~] = segmentDigit(bwImg);

    if isempty(digitCrop)
        predLabels(k) = -1;   % 未检测到数字，标记为-1
        continue;
    end

    normImg = normalizeDigit(digitCrop, targetSize);
    [pred, ~] = templateMatch(normImg, templates);
    predLabels(k) = pred;

    fprintf('%-20s  真实:%d  预测:%d  %s\n', fname, trueLabels(k), pred, ...
        ternaryStr(trueLabels(k)==pred, '正确', '错误'));
end

%% 统计正确率
correct = sum(predLabels == trueLabels);
accuracy = correct / numSamples * 100;
fprintf('\n========================================\n');
fprintf('测试样本总数: %d\n', numSamples);
fprintf('识别正确数  : %d\n', correct);
fprintf('识别正确率  : %.1f%%\n', accuracy);
fprintf('========================================\n');

%% 混淆矩阵
confMat = zeros(10, 10);
for k = 1:numSamples
    if predLabels(k) >= 0
        confMat(trueLabels(k)+1, predLabels(k)+1) = confMat(trueLabels(k)+1, predLabels(k)+1) + 1;
    end
end

figure('Name', '混淆矩阵');
imagesc(confMat);
colormap('parula'); colorbar;
xlabel('预测标签'); ylabel('真实标签');
title(sprintf('数字识别混淆矩阵 (正确率 %.1f%%)', accuracy));
set(gca, 'XTick', 1:10, 'XTickLabel', 0:9, 'YTick', 1:10, 'YTickLabel', 0:9);
for i = 1:10
    for j = 1:10
        if confMat(i,j) > 0
            text(j, i, num2str(confMat(i,j)), 'HorizontalAlignment', 'center', 'Color', 'w');
        end
    end
end

%% 辅助函数：三元表达式（MATLAB无内置三元运算符）
function s = ternaryStr(cond, a, b)
    if cond
        s = a;
    else
        s = b;
    end
end
